//
//  MLFSupport.h
//  MLFSupport
//
//  Copyright © 2019 MLFairy. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MLFSupport.
FOUNDATION_EXPORT double MLFSupportVersionNumber;

//! Project version string for MLFSupport.
FOUNDATION_EXPORT const unsigned char MLFSupportVersionString[];

